export const TOOL = {
    CAMERA: 'camera',
    LINE: 'line',
    SLINE: 'scenery line',
    BRUSH: 'brush',
    SBRUSH: 'scenery brush',
    GRAVITY: 'gravity',
    BOOST: 'boost',
    CHECKPOINT: 'checkpoint',
    SLOWMO: 'slow-mo',
    GOAL: 'goal',
    BOMB: 'bomb',
    ERASER: 'eraser'
};